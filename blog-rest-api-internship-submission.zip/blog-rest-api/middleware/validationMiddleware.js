function validateCreatePost(req, res, next) {
  const required = ['title', 'content', 'authorName', 'category'];
  const errors = [];

  for (const field of required) {
    if (typeof req.body[field] !== 'string' || !req.body[field].trim()) {
      errors.push(`${field} is required and must be a non-empty string.`);
    }
  }

  if (typeof req.body.title === 'string' && req.body.title.trim().length > 150) {
    errors.push('title must not exceed 150 characters.');
  }

  if (errors.length) {
    return res.status(400).json({ success: false, message: 'Validation failed.', errors });
  }
  next();
}

function validateUpdatePost(req, res, next) {
  const allowed = ['title', 'content', 'authorName', 'category'];
  const provided = Object.keys(req.body);
  const invalid = provided.filter((key) => !allowed.includes(key));
  const errors = [];

  if (!provided.length) errors.push('At least one field must be provided for update.');
  if (invalid.length) errors.push(`Unsupported field(s): ${invalid.join(', ')}.`);

  for (const field of provided.filter((key) => allowed.includes(key))) {
    if (typeof req.body[field] !== 'string' || !req.body[field].trim()) {
      errors.push(`${field} must be a non-empty string.`);
    }
  }

  if (typeof req.body.title === 'string' && req.body.title.trim().length > 150) {
    errors.push('title must not exceed 150 characters.');
  }

  if (errors.length) {
    return res.status(400).json({ success: false, message: 'Validation failed.', errors });
  }
  next();
}

module.exports = { validateCreatePost, validateUpdatePost };
