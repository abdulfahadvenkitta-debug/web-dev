const express = require('express');
const {
  createPost,
  getAllPosts,
  getPostById,
  updatePost,
  deletePost
} = require('../controllers/postController');
const { validateCreatePost, validateUpdatePost } = require('../middleware/validationMiddleware');

const router = express.Router();

router.post('/', validateCreatePost, createPost);
router.get('/', getAllPosts);
router.get('/:id', getPostById);
router.put('/:id', validateUpdatePost, updatePost);
router.delete('/:id', deletePost);

module.exports = router;
