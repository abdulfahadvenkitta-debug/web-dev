const { randomUUID } = require('crypto');
const postModel = require('../models/postModel');

async function createPost(req, res, next) {
  try {
    const { title, content, authorName, category } = req.body;

    const post = await postModel.create({
      id: randomUUID(),
      title: title.trim(),
      content: content.trim(),
      authorName: authorName.trim(),
      category: category.trim(),
      createdDate: new Date().toISOString()
    });

    res.status(201).json({
      success: true,
      message: 'Blog post created successfully.',
      data: post
    });
  } catch (error) {
    next(error);
  }
}

async function getAllPosts(req, res, next) {
  try {
    const posts = await postModel.getAll();
    const { category, authorName, search } = req.query;

    let filtered = posts;
    if (category) filtered = filtered.filter((post) => post.category.toLowerCase() === category.toLowerCase());
    if (authorName) filtered = filtered.filter((post) => post.authorName.toLowerCase() === authorName.toLowerCase());
    if (search) {
      const term = search.toLowerCase();
      filtered = filtered.filter((post) =>
        post.title.toLowerCase().includes(term) || post.content.toLowerCase().includes(term)
      );
    }

    res.status(200).json({
      success: true,
      count: filtered.length,
      data: filtered
    });
  } catch (error) {
    next(error);
  }
}

async function getPostById(req, res, next) {
  try {
    const post = await postModel.getById(req.params.id);
    if (!post) {
      return res.status(404).json({ success: false, message: 'Blog post not found.' });
    }

    res.status(200).json({ success: true, data: post });
  } catch (error) {
    next(error);
  }
}

async function updatePost(req, res, next) {
  try {
    const changes = {};
    for (const field of ['title', 'content', 'authorName', 'category']) {
      if (req.body[field] !== undefined) changes[field] = req.body[field].trim();
    }

    const post = await postModel.update(req.params.id, changes);
    if (!post) {
      return res.status(404).json({ success: false, message: 'Blog post not found.' });
    }

    res.status(200).json({
      success: true,
      message: 'Blog post updated successfully.',
      data: post
    });
  } catch (error) {
    next(error);
  }
}

async function deletePost(req, res, next) {
  try {
    const deleted = await postModel.remove(req.params.id);
    if (!deleted) {
      return res.status(404).json({ success: false, message: 'Blog post not found.' });
    }

    res.status(200).json({
      success: true,
      message: 'Blog post deleted successfully.',
      data: deleted
    });
  } catch (error) {
    next(error);
  }
}

module.exports = { createPost, getAllPosts, getPostById, updatePost, deletePost };
