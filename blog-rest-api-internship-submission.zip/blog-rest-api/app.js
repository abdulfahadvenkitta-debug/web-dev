const express = require('express');
const postRoutes = require('./routes/postRoutes');
const { notFound, errorHandler } = require('./middleware/errorMiddleware');

const app = express();

// Built-in middleware for parsing JSON request bodies.
app.use(express.json({ limit: '100kb' }));

// Simple request logger middleware.
app.use((req, res, next) => {
  const started = Date.now();
  res.on('finish', () => {
    console.log(`${req.method} ${req.originalUrl} ${res.statusCode} - ${Date.now() - started}ms`);
  });
  next();
});

app.get('/', (req, res) => {
  res.status(200).json({
    success: true,
    message: 'Welcome to the Blog REST API',
    version: '1.0.0',
    endpoints: {
      create: 'POST /posts',
      getAll: 'GET /posts',
      getOne: 'GET /posts/:id',
      update: 'PUT /posts/:id',
      delete: 'DELETE /posts/:id'
    }
  });
});

app.use('/posts', postRoutes);

app.use(notFound);
app.use(errorHandler);

module.exports = app;
