# Blog REST API with CRUD Operations

A backend REST API developed as a Web Development Internship project using **Node.js** and **Express.js**. The API allows clients to create, read, update and delete blog posts using RESTful HTTP endpoints.

## Features

- Create a blog post
- Retrieve all blog posts
- Retrieve one blog post by ID
- Update an existing blog post
- Delete a blog post
- JSON file data storage
- Input validation
- Centralized error handling
- Meaningful JSON responses
- Appropriate HTTP status codes
- Request logging middleware
- Search and filter support as an additional feature
- Ready-to-import Postman collection
- Automated smoke tests using Node's built-in test runner

## Technologies Used

- Node.js
- Express.js
- REST API
- JavaScript
- JSON file storage
- Postman / Thunder Client / Insomnia

## Project Structure

```text
blog-rest-api/
├── controllers/
│   └── postController.js
├── data/
│   └── posts.json
├── middleware/
│   ├── errorMiddleware.js
│   └── validationMiddleware.js
├── models/
│   └── postModel.js
├── routes/
│   └── postRoutes.js
├── tests/
│   └── api.test.js
├── .env.example
├── .gitignore
├── app.js
├── package.json
├── postman_collection.json
├── README.md
└── server.js
```

## Installation

1. Install Node.js (LTS recommended).
2. Open a terminal in the project folder.
3. Install dependencies:

```bash
npm install
```

4. Start the server:

```bash
npm start
```

The API will run at `http://localhost:3000`.

For development with automatic restart:

```bash
npm run dev
```

## API Endpoints

| Method | Endpoint | Purpose | Success |
|---|---|---|---|
| POST | `/posts` | Create a new blog post | 201 |
| GET | `/posts` | Retrieve all blog posts | 200 |
| GET | `/posts/:id` | Retrieve one blog post | 200 |
| PUT | `/posts/:id` | Update a blog post | 200 |
| DELETE | `/posts/:id` | Delete a blog post | 200 |

### Blog Post Fields

```json
{
  "title": "Getting Started with Node.js",
  "content": "Node.js is a JavaScript runtime used for server-side development.",
  "authorName": "Alex Thomas",
  "category": "Technology"
}
```

`createdDate` is generated automatically by the server. Each post also receives a unique `id`.

## Example Requests

### Create

```http
POST /posts
Content-Type: application/json
```

```json
{
  "title": "My First Blog",
  "content": "This is my first blog post.",
  "authorName": "John Doe",
  "category": "General"
}
```

### Update

```http
PUT /posts/<id>
Content-Type: application/json
```

```json
{
  "title": "My Updated Blog",
  "category": "Technology"
}
```

## Search and Filtering

The API also supports optional query parameters:

- `/posts?search=node` searches title and content.
- `/posts?category=Technology` filters by category.
- `/posts?authorName=John%20Doe` filters by author.

These are bonus features and do not change the required CRUD endpoints.

## HTTP Status Codes

- `200 OK` — successful read, update or delete
- `201 Created` — blog post successfully created
- `400 Bad Request` — validation failure
- `404 Not Found` — post or route does not exist
- `500 Internal Server Error` — unexpected server error

## Testing with Postman

1. Start the server with `npm start`.
2. Open Postman.
3. Import `postman_collection.json`.
4. Run **Create Post** first.
5. Copy the returned `data.id` into the collection variable `postId`.
6. Run the GET, PUT and DELETE requests.
7. Verify status codes and JSON responses.

The same endpoints can be tested using Thunder Client or Insomnia.

## Automated Test

Run:

```bash
npm test
```

This performs basic API smoke tests for validation and 404 handling.

## GitHub Submission

Recommended repository name: `blog-rest-api`

Before submitting:

```bash
git init
git add .
git commit -m "Build Blog REST API with CRUD operations"
git branch -M main
git remote add origin <YOUR_GITHUB_REPOSITORY_URL>
git push -u origin main
```

Do not commit `node_modules`; it is excluded by `.gitignore`.

## Internship Requirement Mapping

- **Node.js / Express.js:** implemented in `server.js` and `app.js`.
- **REST API Design:** resources are exposed through `/posts` using HTTP methods.
- **CRUD:** all five required routes are implemented.
- **Express Routing:** routes are separated in `routes/postRoutes.js`.
- **Middleware:** JSON parsing, request logging, validation and error handling are implemented.
- **Request/Response Handling:** controllers process requests and return structured JSON.
- **Error Handling:** 400, 404 and 500 responses are handled.
- **Data Handling:** posts are persisted in `data/posts.json`.
- **Code Organization:** routes, controllers, model and middleware are separated into modules.
- **API Testing:** Postman collection and automated smoke tests are included.
