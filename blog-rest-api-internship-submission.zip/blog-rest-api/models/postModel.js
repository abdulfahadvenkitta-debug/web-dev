const fs = require('fs/promises');
const path = require('path');

const DATA_FILE = path.join(__dirname, '..', 'data', 'posts.json');

async function ensureDataFile() {
  try {
    await fs.access(DATA_FILE);
  } catch {
    await fs.mkdir(path.dirname(DATA_FILE), { recursive: true });
    await fs.writeFile(DATA_FILE, '[]', 'utf8');
  }
}

async function readPosts() {
  await ensureDataFile();
  const data = await fs.readFile(DATA_FILE, 'utf8');
  return JSON.parse(data || '[]');
}

async function writePosts(posts) {
  await fs.writeFile(DATA_FILE, JSON.stringify(posts, null, 2), 'utf8');
}

async function getAll() {
  return readPosts();
}

async function getById(id) {
  const posts = await readPosts();
  return posts.find((post) => post.id === id) || null;
}

async function create(post) {
  const posts = await readPosts();
  posts.push(post);
  await writePosts(posts);
  return post;
}

async function update(id, changes) {
  const posts = await readPosts();
  const index = posts.findIndex((post) => post.id === id);
  if (index === -1) return null;

  posts[index] = { ...posts[index], ...changes, id, createdDate: posts[index].createdDate };
  await writePosts(posts);
  return posts[index];
}

async function remove(id) {
  const posts = await readPosts();
  const index = posts.findIndex((post) => post.id === id);
  if (index === -1) return null;

  const [deleted] = posts.splice(index, 1);
  await writePosts(posts);
  return deleted;
}

module.exports = { getAll, getById, create, update, remove };
